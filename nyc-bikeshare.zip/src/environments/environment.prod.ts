export const environment = {
  production: true,
  apiUrl: 'https://gbfs.citibikenyc.com/gbfs/en/'
};
